import os
import re
import json
import logging
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
from openai import OpenAI

# Download required NLTK resources
try:
    nltk.data.find('vader_lexicon')
except LookupError:
    nltk.download('vader_lexicon')
    nltk.download('punkt')

# Initialize the sentiment analyzer
sia = SentimentIntensityAnalyzer()

# Initialize OpenAI client
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = OpenAI(api_key=OPENAI_API_KEY)

# Crisis keywords and phrases
CRISIS_KEYWORDS = [
    "suicide", "kill myself", "end my life", "want to die", "don't want to live",
    "self harm", "hurt myself", "cutting myself", "harming myself", 
    "no reason to live", "better off dead", "can't go on", "giving up",
    "life is too hard", "everyone would be better off without me",
    "there's no way out", "no one cares if I'm gone"
]

# Mental health related keywords
ANXIETY_KEYWORDS = [
    "anxiety", "anxious", "panic", "worry", "fear", "nervous", "stressed", 
    "overwhelmed", "can't calm down", "racing thoughts", "constant worry",
    "restless", "on edge", "tension", "can't relax", "heart racing",
    "dread", "apprehension", "uneasy", "scared", "frightened",
    "worried all the time", "overthinking"
]

DEPRESSION_KEYWORDS = [
    "depression", "depressed", "sad", "empty", "hopeless", "worthless", 
    "no energy", "tired all the time", "no motivation", "can't enjoy", 
    "don't care anymore", "nothing matters", "feeling down", "feel numb",
    "lost interest", "can't feel pleasure", "lonely", "isolation",
    "nothing makes me happy", "feel like a failure", "disappoint",
    "let down", "regret", "broken", "darkness", "misery", "despair"
]

STRESS_KEYWORDS = [
    "stress", "stressed", "pressure", "burnout", "exhausted", "overworked",
    "too much", "can't handle", "breaking point", "overwhelmed",
    "burden", "pressure", "deadline", "workload", "responsibilities",
    "too much to do", "time pressure", "can't cope", "frazzled",
    "mental load", "stretched thin", "burnout", "maxed out"
]

# Activity and help-seeking keywords
ACTIVITY_KEYWORDS = [
    "free time", "what to do", "bored", "activities", "hobby", "hobbies",
    "fun things", "what should I do", "ideas for activities", "things to do",
    "pastime", "entertainment", "recreation", "leisure", "relaxation"
]

HAPPINESS_KEYWORDS = [
    "make me happy", "feel better", "cheer up", "improve mood", "happiness",
    "joy", "feel good", "uplift", "lift spirits", "positive feelings",
    "contentment", "satisfaction", "pleasure", "delight", "enjoyment",
    "i am sad", "feeling sad", "unhappy", "down", "blue", "gloomy"
]

PREVENTION_KEYWORDS = [
    "prevent", "prevention", "mental health issues", "avoid depression",
    "avoid anxiety", "stay mentally healthy", "maintain mental health",
    "protect mental health", "mental wellness", "wellbeing strategies",
    "mental fitness", "emotional health", "psychological wellness"
]

def analyze_message(message, current_assessment):
    """
    Analyze a user message for mental health concerns using both
    rule-based detection and sentiment analysis
    """
    message_lower = message.lower()
    
    # Start with current assessment values or defaults
    assessment = current_assessment.copy() if current_assessment else {
        'anxiety': 0,
        'depression': 0,
        'stress': 0,
        'crisis': 0
    }
    
    # Rule-based keyword detection
    # Check for crisis indicators first (highest priority)
    for keyword in CRISIS_KEYWORDS:
        if keyword in message_lower:
            assessment['crisis'] = min(5, assessment['crisis'] + 2)
            break
            
    # Check for other mental health concerns
    for keyword in ANXIETY_KEYWORDS:
        if keyword in message_lower:
            assessment['anxiety'] = min(5, assessment['anxiety'] + 1)
            
    for keyword in DEPRESSION_KEYWORDS:
        if keyword in message_lower:
            assessment['depression'] = min(5, assessment['depression'] + 1)
            
    for keyword in STRESS_KEYWORDS:
        if keyword in message_lower:
            assessment['stress'] = min(5, assessment['stress'] + 1)
            
    # Check for specific help-seeking behaviors
    for keyword in HAPPINESS_KEYWORDS:
        if keyword in message_lower:
            assessment['depression'] = min(5, assessment['depression'] + 1)
            break
            
    for keyword in ACTIVITY_KEYWORDS:
        if keyword in message_lower:
            # Seeking activities is positive, but note interest
            # Don't increase any negative scores, just for tracking
            pass
            
    for keyword in PREVENTION_KEYWORDS:
        if keyword in message_lower:
            # Prevention seeking is positive, just note interest
            # Don't increase any negative scores, just for tracking
            pass
    
    # Sentiment analysis
    sentiment = sia.polarity_scores(message)
    
    # If very negative sentiment, increase depression score
    if sentiment['compound'] < -0.5:
        assessment['depression'] = min(5, assessment['depression'] + 1)
        
    # If high negative, increase stress and anxiety
    if sentiment['neg'] > 0.6:
        assessment['stress'] = min(5, assessment['stress'] + 1)
        assessment['anxiety'] = min(5, assessment['anxiety'] + 1)
    
    # Use OpenAI for enhanced analysis when available
    try:
        if OPENAI_API_KEY:
            openai_analysis = analyze_with_openai(message)
            
            # Incorporate OpenAI analysis, giving it more weight
            for key in ['anxiety', 'depression', 'stress', 'crisis']:
                if key in openai_analysis:
                    # Blend the scores, giving more weight to OpenAI
                    assessment[key] = min(5, (assessment[key] + (openai_analysis[key] * 2)) / 3)
    except Exception as e:
        logging.error(f"Error during OpenAI analysis: {str(e)}")
        # Continue with basic analysis if OpenAI fails
    
    return {
        "assessment": assessment,
        "sentiment": sentiment
    }

def analyze_with_openai(message):
    """
    Use OpenAI to analyze the message for mental health concerns
    Returns a dictionary with scores for different mental health dimensions
    """
    try:
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a mental health analysis assistant. Analyze the following text for signs of "
                        "mental health concerns and rate them on a scale of 0-5, where 0 is no concern and 5 is "
                        "severe concern. Focus on anxiety, depression, stress, and crisis/suicide risk. "
                        "Respond with JSON in this format: "
                        "{'anxiety': number, 'depression': number, 'stress': number, 'crisis': number}"
                    )
                },
                {"role": "user", "content": message}
            ],
            response_format={"type": "json_object"}
        )
        
        # Parse the response
        result = json.loads(response.choices[0].message.content)
        
        # Ensure all required keys are present
        for key in ['anxiety', 'depression', 'stress', 'crisis']:
            if key not in result:
                result[key] = 0
            else:
                # Ensure values are between 0-5
                result[key] = max(0, min(5, result[key]))
                
        return result
    
    except Exception as e:
        logging.error(f"OpenAI analysis error: {str(e)}")
        # Return empty result if OpenAI fails
        return {
            'anxiety': 0,
            'depression': 0,
            'stress': 0,
            'crisis': 0
        }

def get_chatbot_response(user_message, analysis, chat_history):
    """
    Generate an appropriate response based on the user message and analysis
    """
    assessment = analysis['assessment']
    
    # Crisis detection takes precedence - always respond to crisis signals first
    if assessment['crisis'] > 3:
        return (
            "I notice you may be having thoughts of harming yourself or experiencing a crisis. "
            "Please remember that you're not alone, and help is available right now. "
            "Consider contacting a crisis helpline like the 988 Suicide & Crisis Lifeline (call or text 988) "
            "or the Crisis Text Line (text HOME to 741741). "
            "These services are free, confidential, and available 24/7. "
            "Would you like me to provide more specific resources that might help?"
        )
    
    # Try to use OpenAI for a more nuanced response if available
    try:
        if OPENAI_API_KEY:
            # Format the chat history for the API
            formatted_history = []
            for msg in chat_history[-5:]:  # Use last 5 messages for context
                formatted_history.append({"role": msg["role"], "content": msg["content"]})
            
            # Add system message with instructions
            system_message = {
                "role": "system",
                "content": (
                    "You are a compassionate mental health chatbot named MindfulBot. "
                    "Your purpose is to provide emotional support and resources, NOT to diagnose or treat. "
                    "Always clarify that you're not a replacement for professional mental health care. "
                    "Be empathetic, supportive, and encouraging. "
                    "If the user seems to be in crisis, encourage them to seek immediate professional help. "
                    f"Current assessment - Anxiety: {assessment['anxiety']}/5, Depression: {assessment['depression']}/5, "
                    f"Stress: {assessment['stress']}/5, Crisis: {assessment['crisis']}/5"
                )
            }
            
            formatted_history.insert(0, system_message)
            
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = openai.chat.completions.create(
                model="gpt-4o",
                messages=formatted_history,
                max_tokens=300,
                temperature=0.7
            )
            
            return response.choices[0].message.content
    
    except Exception as e:
        logging.error(f"Error generating OpenAI response: {str(e)}")
        # Fall back to rule-based responses if OpenAI fails
    
    # Extract key words/phrases from the user message
    message_lower = user_message.lower()
    
    # Check for specific help requests using our keyword lists
    if any(phrase in message_lower for phrase in HAPPINESS_KEYWORDS):
        return (
            "I understand you're feeling sad. Here are some things that might help improve your mood:\n\n"
            "1. Try physical activity - even a short walk can boost endorphins\n"
            "2. Connect with supportive friends or family members\n"
            "3. Practice gratitude by noting three things you're thankful for\n"
            "4. Listen to uplifting music or watch a comedy\n"
            "5. Get some sunlight and fresh air\n\n"
            "Would you like more specific ideas based on your interests?"
        )
    
    # Free time activities suggestions 
    if any(phrase in message_lower for phrase in ACTIVITY_KEYWORDS):
        return (
            "Here are some mentally healthy ways to spend your free time:\n\n"
            "1. Creative pursuits like drawing, writing, or playing an instrument\n"
            "2. Physical activities like hiking, biking, or yoga\n"
            "3. Mindfulness practices like meditation or deep breathing\n"
            "4. Learning something new through online courses or podcasts\n"
            "5. Connecting with nature through gardening or outdoor walks\n"
            "6. Volunteering to help others\n\n"
            "What kinds of activities do you usually enjoy?"
        )
    
    # Stress quiz and assessment
    if any(keyword in message_lower for keyword in ["stress level", "how stressed", "detect stress", "measure stress", "stress detection", "stress quiz", "stress test", "stress assessment", "quiz", "test"]):
        return (
            "I can help you assess your stress level. We have a comprehensive stress assessment quiz that can provide personalized insights and recommendations.\n\n"
            "The quiz takes about 2-3 minutes to complete and covers different aspects of stress including physical symptoms, emotional responses, and behavioral patterns.\n\n"
            "Would you like to take our stress assessment quiz? Just click this link: [Take Stress Assessment Quiz](/quiz/stress)\n\n"
            "Or I can continue chatting about stress management if you prefer."
        )
    
    # Mental health prevention
    if any(keyword in message_lower for keyword in PREVENTION_KEYWORDS):
        return (
            "Preventing mental health issues involves building good habits:\n\n"
            "1. Maintain regular sleep patterns (7-9 hours nightly)\n"
            "2. Exercise regularly - even 30 minutes of walking daily helps\n"
            "3. Practice mindfulness or meditation to manage stress\n"
            "4. Build and maintain social connections\n"
            "5. Limit alcohol and avoid recreational drugs\n"
            "6. Seek help early when you notice concerning changes\n\n"
            "For a personalized stress prevention plan, I recommend taking our [stress assessment quiz](/quiz/stress). "
            "It provides tailored recommendations based on your specific situation.\n\n"
            "Would you like more specific information about any of these prevention areas?"
        )
    
    # Rule-based fallback responses based on detected concerns
    if assessment['anxiety'] > 2:
        return (
            "I notice you might be feeling anxious. It's normal to feel this way sometimes. "
            "Deep breathing exercises can help - try breathing in for 4 counts, holding for 2, "
            "and exhaling for 6. Would you like to know more about managing anxiety?"
        )
    
    elif assessment['depression'] > 2:
        return (
            "I'm hearing that you might be feeling down. Remember that you're not alone, "
            "and there are resources that can help. Small steps like getting some sunlight "
            "or connecting with a friend can sometimes make a difference. "
            "Would you like to explore some resources for managing depression?"
        )
    
    elif assessment['stress'] > 2:
        return (
            "It sounds like you're dealing with significant stress. Taking short breaks, "
            "practicing mindfulness, or engaging in physical activity might help reduce "
            "your stress levels. Would you like some stress management techniques?"
        )
    
    # General supportive responses if no specific concerns detected
    general_responses = [
        "I'm here to support you. How else can I help today?",
        "Thank you for sharing that with me. Would you like to tell me more about how you're feeling?",
        "I appreciate you opening up. Is there anything specific you'd like support with today?",
        "I'm listening and I care about what you're going through. How else can I support you?",
        "Mental health is important. What specific aspect of mental wellbeing would you like to discuss?",
        "I'm here to help with mental health questions. Could you tell me more about what's on your mind?"
    ]
    
    # Simple selection based on message length
    index = len(user_message) % len(general_responses)
    return general_responses[index]
