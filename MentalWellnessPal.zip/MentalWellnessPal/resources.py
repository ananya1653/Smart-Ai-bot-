# Mental health resources and information

# General mental health resources
mental_health_resources = [
    {
        "id": 1,
        "name": "National Alliance on Mental Illness (NAMI)",
        "description": "NAMI provides advocacy, education, support and public awareness for mental health.",
        "url": "https://www.nami.org",
        "phone": "1-800-950-NAMI (6264)",
        "tags": ["general", "education", "support"]
    },
    {
        "id": 2,
        "name": "Mental Health America",
        "description": "Mental Health America offers information on mental health conditions, treatment options, and resources.",
        "url": "https://www.mhanational.org",
        "phone": "1-800-273-TALK (8255)",
        "tags": ["general", "screening", "resources"]
    },
    {
        "id": 3,
        "name": "Anxiety and Depression Association of America",
        "description": "ADAA provides resources and information specifically for anxiety, depression, and related disorders.",
        "url": "https://adaa.org",
        "phone": "",
        "tags": ["anxiety", "depression", "resources"]
    },
    {
        "id": 4,
        "name": "Psychology Today Therapist Finder",
        "description": "Find therapists, psychiatrists, treatment centers, and support groups near you.",
        "url": "https://www.psychologytoday.com/us/therapists",
        "phone": "",
        "tags": ["therapy", "find help", "professional"]
    },
    {
        "id": 5,
        "name": "Headspace",
        "description": "Meditation and mindfulness app to help with stress, anxiety, sleep, and focus.",
        "url": "https://www.headspace.com",
        "phone": "",
        "tags": ["meditation", "stress", "anxiety", "app"]
    },
    {
        "id": 6,
        "name": "Calm",
        "description": "App for sleep, meditation and relaxation.",
        "url": "https://www.calm.com",
        "phone": "",
        "tags": ["meditation", "sleep", "stress", "app"]
    },
    {
        "id": 7,
        "name": "7 Cups",
        "description": "Online therapy and free support with trained listeners.",
        "url": "https://www.7cups.com",
        "phone": "",
        "tags": ["therapy", "support", "chat"]
    },
    {
        "id": 8,
        "name": "MindTools Stress Management Techniques",
        "description": "Resources and techniques for managing stress and improving wellbeing.",
        "url": "https://www.mindtools.com/pages/main/newMN_TCS.htm",
        "phone": "",
        "tags": ["stress", "techniques", "education"]
    },
    {
        "id": 9,
        "name": "Anxiety Canada",
        "description": "Resources for managing anxiety including self-help strategies and courses.",
        "url": "https://www.anxietycanada.com",
        "phone": "",
        "tags": ["anxiety", "self-help", "education"]
    },
    {
        "id": 10,
        "name": "Depression Center - University of Michigan",
        "description": "Comprehensive information about depression, treatments, and self-care.",
        "url": "https://depressioncenter.org",
        "phone": "",
        "tags": ["depression", "education", "self-help"]
    }
]

# Emergency crisis resources
emergency_resources = [
    {
        "id": 101,
        "name": "988 Suicide & Crisis Lifeline",
        "description": "24/7, free and confidential support for people in distress. Call or text 988.",
        "url": "https://988lifeline.org",
        "phone": "988",
        "tags": ["crisis", "suicide", "emergency"]
    },
    {
        "id": 102,
        "name": "Crisis Text Line",
        "description": "Text HOME to 741741 to connect with a Crisis Counselor. Free 24/7 support.",
        "url": "https://www.crisistextline.org",
        "phone": "Text HOME to 741741",
        "tags": ["crisis", "text", "emergency"]
    },
    {
        "id": 103,
        "name": "SAMHSA's National Helpline",
        "description": "Treatment referral and information service for individuals facing mental health or substance use disorders.",
        "url": "https://www.samhsa.gov/find-help/national-helpline",
        "phone": "1-800-662-HELP (4357)",
        "tags": ["treatment", "substance use", "referral"]
    },
    {
        "id": 104,
        "name": "Veterans Crisis Line",
        "description": "Support for veterans and their loved ones. Connect with responders through a confidential toll-free hotline.",
        "url": "https://www.veteranscrisisline.net",
        "phone": "988, then press 1",
        "tags": ["veterans", "crisis", "emergency"]
    },
    {
        "id": 105,
        "name": "The Trevor Project",
        "description": "Crisis intervention and suicide prevention services for LGBTQ young people under 25.",
        "url": "https://www.thetrevorproject.org",
        "phone": "1-866-488-7386",
        "tags": ["LGBTQ", "youth", "crisis"]
    }
]

# Educational content about common mental health conditions
mental_health_education = {
    "anxiety": {
        "title": "Understanding Anxiety",
        "description": "Anxiety is the body's natural response to stress. While occasional anxiety is normal, persistent, excessive worry may indicate an anxiety disorder.",
        "symptoms": [
            "Excessive worry", 
            "Restlessness", 
            "Fatigue", 
            "Difficulty concentrating", 
            "Irritability",
            "Muscle tension",
            "Sleep problems"
        ],
        "self_help": [
            "Practice deep breathing exercises",
            "Regular physical activity",
            "Adequate sleep",
            "Limit caffeine and alcohol",
            "Mindfulness and meditation",
            "Challenge negative thoughts"
        ]
    },
    "depression": {
        "title": "Understanding Depression",
        "description": "Depression is a common but serious mood disorder that affects how you feel, think, and handle daily activities.",
        "symptoms": [
            "Persistent sad, anxious, or 'empty' mood",
            "Loss of interest in activities once enjoyed",
            "Decreased energy or fatigue",
            "Difficulty sleeping or oversleeping",
            "Changes in appetite or weight",
            "Thoughts of death or suicide",
            "Difficulty concentrating or making decisions"
        ],
        "self_help": [
            "Stay connected with supportive people",
            "Engage in physical activity",
            "Set realistic goals",
            "Challenge negative thoughts",
            "Postpone important decisions until feeling better",
            "Establish regular routines"
        ]
    },
    "stress": {
        "title": "Managing Stress",
        "description": "Stress is a normal psychological and physical reaction to demands of life, but chronic stress can affect your health.",
        "symptoms": [
            "Headaches",
            "Upset stomach",
            "Elevated blood pressure",
            "Chest pain",
            "Sleep problems",
            "Irritability or anger",
            "Feeling overwhelmed"
        ],
        "self_help": [
            "Regular physical activity",
            "Relaxation techniques (deep breathing, meditation, yoga)",
            "Maintain a healthy diet",
            "Get adequate sleep",
            "Set priorities and boundaries",
            "Make time for hobbies and activities you enjoy"
        ]
    }
}
