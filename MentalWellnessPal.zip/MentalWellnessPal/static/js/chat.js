document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const chatForm = document.getElementById('chatForm');
    const userMessageInput = document.getElementById('userMessage');
    const chatMessages = document.getElementById('chatMessages');
    const clearChatBtn = document.getElementById('clearChatBtn');
    const suggestedResources = document.getElementById('suggestedResources');
    const resourcesList = document.getElementById('resourcesList');
    const emergencyAlert = document.getElementById('emergencyAlert');
    
    // Function to add a new message to the chat
    function addMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        
        // Process message content for links
        const processedContent = processLinks(content);
        messageContent.innerHTML = processedContent;
        
        // Add timestamp
        const timestamp = document.createElement('div');
        timestamp.className = 'message-time';
        const time = new Date();
        timestamp.textContent = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageDiv.appendChild(messageContent);
        messageDiv.appendChild(timestamp);
        
        // For screen readers
        const srMessage = isUser ? 'You: ' : 'MindfulBot: ';
        messageDiv.setAttribute('aria-label', srMessage + content);
        
        chatMessages.appendChild(messageDiv);
        
        // Scroll to the bottom of the chat
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to show typing indicator
    function showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.id = 'typingIndicator';
        indicator.setAttribute('aria-label', 'MindfulBot is typing');
        
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('span');
            indicator.appendChild(dot);
        }
        
        chatMessages.appendChild(indicator);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to remove typing indicator
    function removeTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.remove();
        }
    }
    
    // Function to process links in text
    function processLinks(text) {
        // Convert URLs to clickable links
        const urlRegex = /(https?:\/\/[^\s]+)/g;
        const processedText = text.replace(urlRegex, function(url) {
            return `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`;
        });
        
        // Convert newlines to <br> tags
        return processedText.replace(/\n/g, '<br>');
    }
    
    // Function to render suggested resources
    function renderSuggestedResources(resources) {
        if (!resources || resources.length === 0) {
            suggestedResources.classList.add('d-none');
            return;
        }
        
        // Clear previous resources
        resourcesList.innerHTML = '';
        
        // Add new resources
        resources.forEach(resource => {
            const resourceItem = document.createElement('a');
            resourceItem.href = resource.url;
            resourceItem.className = 'list-group-item list-group-item-action d-flex align-items-center';
            resourceItem.target = '_blank';
            resourceItem.rel = 'noopener noreferrer';
            
            resourceItem.innerHTML = `
                <div>
                    <div class="fw-semibold">${resource.name}</div>
                    <div class="small text-body-secondary">${resource.description}</div>
                </div>
                <i class="fas fa-external-link-alt ms-auto"></i>
            `;
            
            resourcesList.appendChild(resourceItem);
        });
        
        // Show the resources section
        suggestedResources.classList.remove('d-none');
    }
    
    // Handle form submission
    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const userMessage = userMessageInput.value.trim();
        if (!userMessage) return;
        
        // Add user message to chat
        addMessage(userMessage, true);
        
        // Clear input field
        userMessageInput.value = '';
        
        // Show typing indicator
        showTypingIndicator();
        
        // Send message to server
        fetch('/send_message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: userMessage })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Remove typing indicator
            removeTypingIndicator();
            
            // Add bot response to chat
            addMessage(data.message);
            
            // Show or hide emergency alert
            if (data.show_emergency) {
                emergencyAlert.classList.remove('d-none');
            } else {
                emergencyAlert.classList.add('d-none');
            }
            
            // Display suggested resources if any
            renderSuggestedResources(data.resources);
        })
        .catch(error => {
            console.error('Error:', error);
            removeTypingIndicator();
            
            // Add error message
            addMessage('Sorry, there was an error processing your message. Please try again.');
        });
    });
    
    // Handle clear chat button
    clearChatBtn.addEventListener('click', function() {
        // Confirm before clearing
        if (confirm('Are you sure you want to clear the chat history? This cannot be undone.')) {
            fetch('/clear_chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to clear chat');
                }
                return response.json();
            })
            .then(() => {
                // Clear chat UI
                chatMessages.innerHTML = '';
                
                // Add welcome message
                addMessage('Hi there! I\'m MindfulBot, your mental wellness companion. How are you feeling today?');
                
                // Hide resources and emergency alert
                suggestedResources.classList.add('d-none');
                emergencyAlert.classList.add('d-none');
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to clear chat history. Please try again.');
            });
        }
    });
    
    // Keyboard shortcuts
    userMessageInput.addEventListener('keydown', function(e) {
        // Escape to clear input
        if (e.key === 'Escape') {
            userMessageInput.value = '';
        }
    });
    
    // Focus input field when page loads
    userMessageInput.focus();
});
