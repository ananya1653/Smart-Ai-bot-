"""
Stress assessment and mental health quiz module for the MindfulBot application
"""

# Stress Assessment Quiz
STRESS_QUIZ = {
    "title": "Stress Level Assessment",
    "description": "This quiz helps identify your current stress level and provides personalized recommendations.",
    "instructions": "Rate each statement on a scale from 0 (Never) to 4 (Very Often) based on your experiences over the past month.",
    "questions": [
        {
            "id": 1,
            "text": "How often have you felt that you were unable to control the important things in your life?",
            "category": "perceived_control"
        },
        {
            "id": 2,
            "text": "How often have you felt nervous and stressed?",
            "category": "emotional_response"
        },
        {
            "id": 3,
            "text": "How often have you found that you could not cope with all the things that you had to do?",
            "category": "coping_ability"
        },
        {
            "id": 4,
            "text": "How often have you felt difficulties were piling up so high that you could not overcome them?",
            "category": "overwhelm"
        },
        {
            "id": 5,
            "text": "How often have you had trouble sleeping because of your worries?",
            "category": "physical_symptoms"
        },
        {
            "id": 6,
            "text": "How often have you felt irritable or easily angered?",
            "category": "mood_changes"
        },
        {
            "id": 7,
            "text": "How often have you had difficulty concentrating or making decisions?",
            "category": "cognitive_function"
        },
        {
            "id": 8,
            "text": "How often have you experienced physical symptoms like headaches, muscle tension, or digestive issues?",
            "category": "physical_symptoms"
        },
        {
            "id": 9,
            "text": "How often have you felt unable to relax or take time for yourself?",
            "category": "self_care"
        },
        {
            "id": 10,
            "text": "How often have you felt worn out or exhausted without a clear physical reason?",
            "category": "energy_levels"
        }
    ],
    "scoring": {
        "ranges": [
            {"min": 0, "max": 13, "level": "Low", "color": "green"},
            {"min": 14, "max": 26, "level": "Moderate", "color": "yellow"},
            {"min": 27, "max": 40, "level": "High", "color": "red"}
        ]
    }
}

# Prevention Strategies by Stress Level
PREVENTION_STRATEGIES = {
    "Low": [
        "Continue with your current self-care practices as they're working well.",
        "Maintain regular physical activity (30 minutes most days).",
        "Keep up your social connections and support network.",
        "Practice mindfulness or relaxation techniques to stay centered.",
        "Get 7-9 hours of quality sleep consistently."
    ],
    "Moderate": [
        "Incorporate daily relaxation techniques like deep breathing or progressive muscle relaxation.",
        "Evaluate your commitments and consider what you might delegate or postpone.",
        "Increase physical activity to help reduce stress hormones.",
        "Establish clear boundaries between work and personal time.",
        "Limit caffeine and alcohol as they can exacerbate stress symptoms.",
        "Consider talking to a trusted friend or family member about your stressors."
    ],
    "High": [
        "Consider speaking with a mental health professional for personalized strategies.",
        "Implement stress-reduction breaks throughout your day (even 5 minutes helps).",
        "Prioritize self-care activities that you enjoy and find calming.",
        "Use structured problem-solving techniques for stressors within your control.",
        "Ensure adequate sleep and nutrition as foundations for stress management.",
        "Limit exposure to stressful media and news if it's contributing to your stress.",
        "Explore whether workplace accommodations or changes might reduce your stress."
    ]
}

# Warning Signs by Category
WARNING_SIGNS = {
    "perceived_control": "Feeling a lack of control can increase stress levels and anxiety. Consider focusing on aspects of your life you can directly influence.",
    "emotional_response": "Strong emotional reactions may indicate your stress response system is frequently activated. Emotion regulation techniques like mindfulness can help.",
    "coping_ability": "Difficulty coping suggests your resources may be stretched. Consider what responsibilities could be delegated or postponed.",
    "overwhelm": "Feeling overwhelmed is a key indicator of excessive stress. Breaking tasks into smaller steps can help restore a sense of manageability.",
    "physical_symptoms": "Physical symptoms are common stress responses. Pay attention to these signals as early warnings from your body.",
    "mood_changes": "Irritability and mood swings often accompany chronic stress. These can impact relationships and may benefit from targeted stress reduction.",
    "cognitive_function": "Stress significantly affects concentration and decision-making. Mental clarity often improves as stress levels decrease.",
    "self_care": "Neglecting self-care during stress creates a negative cycle. Even small self-care acts can break this pattern.",
    "energy_levels": "Fatigue is both a symptom and contributor to stress. Energy management strategies can help restore your resources."
}

def calculate_stress_score(answers):
    """
    Calculate total stress score from quiz answers
    
    Args:
        answers: Dictionary with question IDs as keys and ratings (0-4) as values
        
    Returns:
        Dictionary with score, level, and applicable prevention strategies
    """
    # Validate answers
    if not answers or not isinstance(answers, dict):
        return {"error": "Invalid answers format"}
    
    # Calculate total score
    total_score = sum(answers.values())
    
    # Determine stress level
    stress_level = None
    stress_color = "gray"  # Default color
    for range_info in STRESS_QUIZ["scoring"]["ranges"]:
        if range_info["min"] <= total_score <= range_info["max"]:
            stress_level = range_info["level"]
            stress_color = range_info["color"]
            break
    
    if not stress_level:
        return {"error": "Could not determine stress level"}
    
    # Get prevention strategies for this level
    strategies = PREVENTION_STRATEGIES.get(stress_level, [])
    
    # Identify key areas of concern (categories with highest scores)
    category_scores = {}
    for q_id, score in answers.items():
        # Find the question by ID
        question = next((q for q in STRESS_QUIZ["questions"] if q["id"] == q_id), None)
        if question:
            category = question["category"]
            if category in category_scores:
                category_scores[category] += score
            else:
                category_scores[category] = score
    
    # Get top concerns (categories with highest scores)
    top_concerns = []
    if category_scores:
        # Sort categories by score (descending)
        sorted_categories = sorted(category_scores.items(), key=lambda x: x[1], reverse=True)
        # Get top 3 or fewer if there aren't that many
        top_categories = sorted_categories[:min(3, len(sorted_categories))]
        
        # Get warning signs for top categories
        for category, score in top_categories:
            if score > 2:  # Only include if score indicates concern
                top_concerns.append({
                    "category": category,
                    "guidance": WARNING_SIGNS.get(category, "")
                })
    
    return {
        "score": total_score,
        "level": stress_level,
        "color": stress_color,
        "strategies": strategies,
        "top_concerns": top_concerns
    }

def get_quiz_questions():
    """Return the stress assessment quiz questions"""
    return {
        "title": STRESS_QUIZ["title"],
        "description": STRESS_QUIZ["description"],
        "instructions": STRESS_QUIZ["instructions"],
        "questions": STRESS_QUIZ["questions"]
    }