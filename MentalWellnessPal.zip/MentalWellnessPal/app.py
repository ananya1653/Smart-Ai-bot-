import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
import uuid

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create database base class
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Configure the database connection
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///mental_health_chatbot.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the app with the database extension
db.init_app(app)

# Import resources after app is created to avoid circular imports
from resources import mental_health_resources, emergency_resources
from chatbot import analyze_message, get_chatbot_response
from quiz import get_quiz_questions, calculate_stress_score

# Create all database tables
with app.app_context():
    # Import models here to ensure they're registered
    import models
    db.create_all()

# Ensure user has a session ID
@app.before_request
def create_session():
    if 'user_id' not in session:
        session['user_id'] = str(uuid.uuid4())
        session['chat_history'] = []
        session['current_assessment'] = {
            'anxiety': 0,
            'depression': 0,
            'stress': 0,
            'crisis': 0
        }

# Routes
@app.route('/')
def index():
    return render_template('index.html', now=datetime.now())

@app.route('/privacy')
def privacy():
    return render_template('privacy.html', now=datetime.now())

@app.route('/resources')
def resources():
    return render_template(
        'resources.html', 
        mental_health_resources=mental_health_resources,
        emergency_resources=emergency_resources,
        now=datetime.now()
    )

@app.route('/quiz/stress', methods=['GET'])
def stress_quiz():
    """Return the stress assessment quiz page"""
    return render_template('stress_quiz.html', now=datetime.now())

@app.route('/api/quiz/stress', methods=['GET'])
def get_stress_quiz():
    """Return the stress assessment quiz questions as JSON"""
    return jsonify(get_quiz_questions())

@app.route('/api/quiz/stress/submit', methods=['POST'])
def submit_stress_quiz():
    """Process stress quiz answers and return results"""
    try:
        answers = request.json.get('answers', {})
        if not answers:
            return jsonify({'error': 'No answers provided'}), 400
            
        # Convert answer keys from strings to integers
        formatted_answers = {int(k): int(v) for k, v in answers.items()}
        
        # Calculate results
        results = calculate_stress_score(formatted_answers)
        
        # Store results in session
        session['stress_quiz_results'] = results
        
        return jsonify(results)
    except Exception as e:
        logging.error(f"Error processing quiz results: {str(e)}")
        return jsonify({'error': 'An error occurred while processing your quiz results'}), 500

@app.route('/clear_chat', methods=['POST'])
def clear_chat():
    session['chat_history'] = []
    session['current_assessment'] = {
        'anxiety': 0,
        'depression': 0,
        'stress': 0,
        'crisis': 0
    }
    return jsonify({'status': 'success'})

@app.route('/send_message', methods=['POST'])
def send_message():
    try:
        user_message = request.json.get('message', '').strip()
        
        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Get chat history
        chat_history = session.get('chat_history', [])
        
        # Add user message to history
        chat_history.append({"role": "user", "content": user_message})
        
        # Analyze the message for sentiment and potential concerns
        analysis = analyze_message(user_message, session.get('current_assessment', {}))
        
        # Update session with analysis results
        session['current_assessment'] = analysis['assessment']
        
        # Get appropriate chatbot response
        bot_response = get_chatbot_response(user_message, analysis, chat_history)
        
        # Add bot response to history (limit history to last 10 messages for performance)
        chat_history.append({"role": "assistant", "content": bot_response})
        if len(chat_history) > 20:
            chat_history = chat_history[-20:]
        
        # Update session
        session['chat_history'] = chat_history
        
        # Prepare suggested resources based on detected concerns
        suggested_resources = []
        assessment = session['current_assessment']
        
        # Check if any assessment values exceed thresholds to suggest resources
        if assessment['anxiety'] > 2:
            suggested_resources.extend([r for r in mental_health_resources if 'anxiety' in r['tags']])
        if assessment['depression'] > 2:
            suggested_resources.extend([r for r in mental_health_resources if 'depression' in r['tags']])
        if assessment['stress'] > 2:
            suggested_resources.extend([r for r in mental_health_resources if 'stress' in r['tags']])
        if assessment['crisis'] > 3:
            suggested_resources.extend(emergency_resources)
        
        # Remove duplicates and limit to 3 suggestions
        unique_resources = []
        resource_ids = set()
        for resource in suggested_resources:
            if resource['id'] not in resource_ids:
                resource_ids.add(resource['id'])
                unique_resources.append(resource)
        
        suggested_resources = unique_resources[:3]
        
        return jsonify({
            'message': bot_response,
            'resources': suggested_resources,
            'show_emergency': assessment['crisis'] > 3
        })
        
    except Exception as e:
        logging.error(f"Error processing message: {str(e)}")
        return jsonify({'error': 'An error occurred while processing your message'}), 500
