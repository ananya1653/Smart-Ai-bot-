from app import db
from datetime import datetime

class ChatSession(db.Model):
    """Model for storing chat sessions"""
    id = db.Column(db.String(36), primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    messages = db.relationship('ChatMessage', backref='session', lazy=True, cascade="all, delete-orphan")
    assessment = db.relationship('MentalHealthAssessment', backref='session', uselist=False, cascade="all, delete-orphan")

class ChatMessage(db.Model):
    """Model for storing individual chat messages"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(36), db.ForeignKey('chat_session.id'), nullable=False)
    role = db.Column(db.String(10), nullable=False)  # 'user' or 'assistant'
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
class MentalHealthAssessment(db.Model):
    """Model for storing mental health assessments based on conversations"""
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(36), db.ForeignKey('chat_session.id'), nullable=False)
    anxiety_level = db.Column(db.Integer, default=0)  # 0-5 scale
    depression_level = db.Column(db.Integer, default=0)  # 0-5 scale
    stress_level = db.Column(db.Integer, default=0)  # 0-5 scale
    crisis_level = db.Column(db.Integer, default=0)  # 0-5 scale
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
